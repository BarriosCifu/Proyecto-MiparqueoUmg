/*
 * Isaias Barrios
 */
package com.mycompany.miparqueoumg;


public class MiparqueoUmg {
    public static void main(String[] args) {
    Login ingresar = new Login();
    ingresar.setVisible(true);
    }
}
